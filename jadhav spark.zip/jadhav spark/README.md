# Salary Data Analysis Web Application

This is a web-based application for analyzing salary data with interactive visualizations and filtering capabilities.

## Features

- Upload and analyze salary data from CSV files
- Interactive charts for data visualization
- Filtering by job title and experience level
- Summary statistics (average, median, min, max salary)
- Responsive design that works on desktop and mobile devices
- Comes with built-in sample data for immediate use

## How to Use

1. Open `index.html` in a web browser
2. The application loads with 30 built-in sample records automatically
3. To use your own data:
   - Prepare a CSV file with columns: Name, Job Title, Experience, Salary, Department
   - Click "Choose File" and select your CSV file
   - Click "Upload CSV File"
4. Apply filters using the dropdown menus to narrow down your data
5. View the results in the charts and data table
6. Check the summary statistics for key insights

## Built-in Sample Data

The application comes with 30 sample employee records across various departments and experience levels. You can immediately explore the features without uploading any data.

## CSV File Format

To use your own data, create a CSV file with the following columns:
- Name
- Job Title
- Experience (Entry-Level, Mid-Level, Senior)
- Salary (numeric value)
- Department

See `sample_salary_data.csv` for an example.

## Technical Details

- Built with HTML, CSS, and vanilla JavaScript
- Uses Chart.js for data visualization
- No external dependencies except for Chart.js CDN
- Fully client-side processing (no server required)

## Browser Support

Works in all modern browsers (Chrome, Firefox, Safari, Edge).

## License

This project is open source and available under the MIT License.